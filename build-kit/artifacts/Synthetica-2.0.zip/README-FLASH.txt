Synthetica 2.0 - READ THIS BEFORE FLASHING
=====================================================

What this is
------------
Kernel 4.14.357-openela-Synthetica-2.0 for miatoll / joyeuse (Redmi Note 9S / 9 Pro family),
with the in-tree KernelSU-Next driver of the Rollercoaster 1.2.0 base built in
(ksun-legacy-susfs-v2, declared 34000, manual hook; root is mandatory).
The manager APK must be the one that driver accepts (Rollercoaster SU 1.0.0),
and the installer writes ksud to /data/adb/ksud - data has to be decrypted in recovery.
Installed through AnyKernel3: it replaces the kernel inside the boot partition and keeps
your existing ramdisk. No modules, no /vendor changes, no auto reboot.

Installer behaviour (2.0)
-------------------------
* No boot backup: the backup step was removed by request in 2.0.
* The installer writes an installation log to <storage>/Synthetica/install-log-<time>.txt
  (kernel string, image hash, ksud result, write result).
* Keep your own boot backup from a previous release if you want a way back.

How to flash
------------
1. Boot to recovery.
2. Make sure /sdcard is mounted and data is decrypted (ksud needs /data/adb).
3. Flash Synthetica-2.0.zip.
4. Install Synthetica-2.0.apk (the manager from the same batch) after reboot.
5. Reboot only when you are ready.

If it does not boot
-------------------
1. Boot back to recovery. Do NOT wipe data.
2. Flash Synthetica-2.0-LOG.zip and send <storage>/synthetica-logs/<timestamp>/.
3. Restore a boot image you backed up yourself, or reflash the previous kernel.
