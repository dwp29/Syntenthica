SYNTHETICA-PULSE 2.0 log collector
===================================
Read-only recovery tool. Collects dmesg, /proc/last_kmsg, pstore, recovery logs,
mounts, module list and boot/dtbo/vbmeta hashes into
<storage>/synthetica-logs/<timestamp>/ and a .tar.gz next to it.
It does not modify any partition. Safe to run repeatedly; safe to run even when
the phone is healthy.
