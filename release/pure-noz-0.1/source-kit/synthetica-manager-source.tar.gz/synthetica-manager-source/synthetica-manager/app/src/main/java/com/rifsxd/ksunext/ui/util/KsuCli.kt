package com.rifsxd.ksunext.ui.util

import android.app.Activity
import android.content.Intent
import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.os.Parcelable
import android.os.SystemClock
import android.provider.OpenableColumns
import android.system.Os
import android.util.Log
import com.rifsxd.ksunext.BuildConfig
import com.rifsxd.ksunext.Natives
import com.rifsxd.ksunext.R
import com.rifsxd.ksunext.ui.preflight.AndroidZipPreflight
import com.rifsxd.ksunext.ksuApp
import com.topjohnwu.superuser.CallbackList
import com.topjohnwu.superuser.Shell
import com.topjohnwu.superuser.ShellUtils
import com.topjohnwu.superuser.io.SuFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.parcelize.Parcelize
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * @author weishu
 * @date 2023/1/1.
 */
private const val TAG = "KsuCli"
private const val BUSYBOX = "/data/adb/ksu/bin/busybox"

private fun getKsuDaemonPath(): String {
    return ksuApp.applicationInfo.nativeLibraryDir + File.separator + "libksud.so"
}

/**
 * Which chain of commands produced the root shell. Kept as an enum so callers
 * (diagnostics, UI) can show the truth instead of guessing.
 */
enum class RootChannel {
    /** `su` exists and the user granted it, but the shell is not uid 0. */
    SU_DENIED,

    /** /system/bin/su — KernelSU family (BakaSU, SukiSU, APatch), Magisk. */
    SU,

    /** /system/bin/su does not exist at all on this device. */
    SU_ABSENT,

    /** Synthetica's own libksud.so, UAPI 4. */
    KSUD,

    /** Nothing granted root; the shell is a plain uid 2000 shell. */
    NONE,
}

/**
 * Root shell for BOTH ecosystems, built as an explicit fallback chain.
 *
 * Plain `su` comes first, ALWAYS. This is the bug that made a rooted KernelSU
 * device look unrooted: the previously shipped chain started with
 * `su --mount-master`, which KernelSU's su does not implement — it exits
 * non-zero and prints usage instead of granting a shell. Because the shell sat
 * in a mount-master namespace for every caller (the default builder passes
 * `globalMnt = true`), a perfectly good root was never reached.
 *
 * `su --mount-master` is therefore only a *fallback* after plain `su` failed,
 * which is where Magisk accepts it. `-g` on KernelSU's su means "group", not
 * "global mount", so the long form is used and only when it can help.
 *
 * `libksud.so debug su` is last before the `sh` tail: that binary ships inside
 * our APK regardless of the kernel, so it must never be tried first, or a
 * foreign ksud would shadow a perfectly good su. In ksud's clap definition
 * `global_mnt` takes both `-g` and `--global-mnt`; the long form is used here.
 *
 * A plain `sh` tail keeps an unrooted device usable; it never claims root.
 */
fun createRootShellBuilder(globalMnt: Boolean = false): Shell.Builder {
    return Shell.Builder.create().run {
        val ksud = getKsuDaemonPath()
        val cmd = buildString {
            // Plain su first: it is the only form every su implementation
            // supports, and on KernelSU it is what the user approves. Asking
            // for --mount-master first made KernelSU's su print its usage and
            // exit, so the whole chain fell through to the unprivileged sh.
            append("su || ")
            append("$ksud debug su")
            if (globalMnt) append(" --global-mnt")
            append(" || ")
            // Only now, when plain su has already failed, try the mount-master
            // namespace that Magisk understands. A kernel that rejects it has
            // still had its chance to answer the plain su above.
            if (globalMnt) {
                append("su --mount-master || ")
            }
            append("sh")
        }
        setCommands("sh", "-c", cmd)
    }
}

/**
 * Which layer is answering, derived from facts only:
 * a live UID-0 `su` means the kernel's own root channel, otherwise the KSU
 * driver tells us whether our libksud can be used, otherwise there is nothing.
 */
suspend fun detectRootChannel(): RootChannel = withContext(Dispatchers.IO) {
    when {
        probeSuRoot() -> RootChannel.SU
        runCatching { Natives.isManager }.getOrDefault(false) -> RootChannel.KSUD
        // Distinguish "su is there but not granted" from "there is no su at
        // all". Without this the UI told the user the KSU driver rejected the
        // APK when usually nothing had ever asked the user to grant root.
        suBinaryPresent() -> RootChannel.SU_DENIED
        else -> RootChannel.SU_ABSENT
    }
}

data class FlashResult(val code: Int, val err: String, val showReboot: Boolean) {
    constructor(result: Shell.Result, showReboot: Boolean) : this(result.code, result.err.joinToString("\n"), showReboot)
    constructor(result: Shell.Result) : this(result, result.isSuccess)
}

inline fun <T> withNewRootShell(
    globalMnt: Boolean = false,
    block: Shell.() -> T
): T {
    return createRootShell(globalMnt).use(block)
}

fun Uri.getFileName(context: Context): String? {
    var fileName: String? = null
    val contentResolver: ContentResolver = context.contentResolver
    val cursor: Cursor? = contentResolver.query(this, null, null, null, null)
    cursor?.use {
        if (it.moveToFirst()) {
            fileName = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
        }
    }
    return fileName
}


fun createRootShell(globalMnt: Boolean = false): Shell {
    return runCatching {
        createRootShellBuilder(globalMnt).build()
    }.getOrElse { e ->
        Log.w(TAG, "su failed: ", e)
        Shell.Builder.create().apply {
            if (globalMnt) setFlags(Shell.FLAG_MOUNT_MASTER)
        }.build()
    }
}

fun execKsud(args: String, newShell: Boolean = false, globalMnt: Boolean = false): Boolean {
    return if (newShell) {
        withNewRootShell(globalMnt = globalMnt) {
            ShellUtils.fastCmdResult(this, "${getKsuDaemonPath()} $args")
        }
    } else {
        ShellUtils.fastCmdResult("${getKsuDaemonPath()} $args")
    }
}

suspend fun getFeatureStatus(feature: String): String = withContext(Dispatchers.IO) {
    val shell = createRootShell(true)
    
    val out = shell.newJob()
        .add("${getKsuDaemonPath()} feature check $feature").to(ArrayList<String>(), null).exec().out
    out.firstOrNull()?.trim().orEmpty()
}

suspend fun getFeaturePersistValue(feature: String): Long? = withContext(Dispatchers.IO) {
    val shell = createRootShell(true)
    
    val out = shell.newJob()
        .add("${getKsuDaemonPath()} feature get --config $feature").to(ArrayList<String>(), null).exec().out
    val valueLine = out.firstOrNull { it.trim().startsWith("Value:") } ?: return@withContext null
    valueLine.substringAfter("Value:").trim().toLongOrNull()
}

fun install() {
    val start = SystemClock.elapsedRealtime()
    val libadbroot = File(ksuApp.applicationInfo.nativeLibraryDir, "libadbroot.so").absolutePath
    val result = execKsud("install --libadbroot $libadbroot", true)
    Log.w(TAG, "install result: $result, cost: ${SystemClock.elapsedRealtime() - start}ms")
}

fun listModules(): String {
    val out =
        Shell.cmd("${getKsuDaemonPath()} module list").to(ArrayList(), null).exec().out
    return out.joinToString("\n").ifBlank { "[]" }
}

fun getModuleCount(): Int {
    return runCatching {
        JSONArray(listModules()).length()
    }.getOrDefault(0)
}

fun getSuperuserCount(): Int {
    return Natives.getSuperuserCount()
}

fun toggleModule(id: String, enable: Boolean): Boolean {
    val cmd = if (enable) {
        "module enable $id"
    } else {
        "module disable $id"
    }
    val result = execKsud(cmd, true)
    Log.i(TAG, "$cmd result: $result")
    return result
}

fun uninstallModule(id: String): Boolean {
    val cmd = "module uninstall $id"
    val result = execKsud(cmd, true)
    Log.i(TAG, "uninstall module $id result: $result")
    return result
}

fun restoreModule(id: String): Boolean {
    val cmd = "module restore $id"
    val result = execKsud(cmd, true)
    Log.i(TAG, "restore module $id result: $result")
    return result
}

fun getSelinuxEnforce(): Boolean? {
    return runCatching {
        val out = ShellUtils.fastCmd("getenforce").trim()
        when {
            out.equals("Enforcing", ignoreCase = true) -> true
            out.equals("Permissive", ignoreCase = true) -> false
            else -> null
        }
    }.getOrNull()
}

fun setSelinuxEnforce(enforce: Boolean): Boolean {
    return runCatching {
        val valStr = if (enforce) "1" else "0"
        ShellUtils.fastCmdResult("setenforce $valStr")
    }.getOrDefault(false)
}

private fun processUiPrintLine(s: String?): Pair<Int, String?> {
    if (s == null) {
        return Pair(1,null)
    }

    val check1 = s.startsWith("ui_print")
    val trimmed = s.trim()
    val check2 = trimmed.startsWith("ui_print")
    if (!check1 && check2) return Pair(1,null)

    return if(check1) {
        Pair(1,trimmed.drop(8).dropWhile { it.isWhitespace() })
    }
    else {
        Pair(2, trimmed)
    }
}

private fun flashWithIO_ak3(
    cmd: String,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): Shell.Result {

    val stdoutCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            val (type, text) = processUiPrintLine(s)
            if(type == 1) {
                text?.let(onStdout)
            } else {
                text?.let(onStderr)
            }
        }
    }

    val stderrCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStderr(s ?: "")
        }
    }

    return withNewRootShell {
        newJob().add(cmd).to(stdoutCallback, stderrCallback).exec()
    }
}

private fun flashWithIO(
    cmd: String,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): Shell.Result {

    val stdoutCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStdout(s ?: "")
        }
    }

    val stderrCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStderr(s ?: "")
        }
    }

    return withNewRootShell {
        newJob().add(cmd).to(stdoutCallback, stderrCallback).exec()
    }
}

fun flashModule(
    uri: Uri,
    approvedSha256: String,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): FlashResult {
    val file = runCatching { File.createTempFile("module31-", ".zip", ksuApp.cacheDir) }.getOrNull()
    if (file == null || !AndroidZipPreflight.copyVerified(ksuApp, uri, file, approvedSha256)) {
        val message = ksuApp.getString(R.string.zip31_changed)
        onStderr(message)
        return FlashResult(1, message, false)
    }
    try {
        val cmd = "module install ${file.absolutePath}"
        val result = flashWithIO("${getKsuDaemonPath()} $cmd", onStdout, onStderr)
        Log.i("KernelSU", "install module $uri result: $result")
        return FlashResult(result)
    } finally {
        file.delete()
    }
}

fun runModuleAction(
    moduleId: String, onStdout: (String) -> Unit, onStderr: (String) -> Unit
): Boolean {
    val shell = createRootShell(true)

    val stdoutCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStdout(s ?: "")
        }
    }

    val stderrCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStderr(s ?: "")
        }
    }

    val result = shell.newJob().add("${getKsuDaemonPath()} module action $moduleId")
        .to(stdoutCallback, stderrCallback).exec()
    Log.i("KernelSU", "Module runAction result: $result")

    return result.isSuccess
}

fun restoreBoot(
    onStdout: (String) -> Unit, onStderr: (String) -> Unit
): FlashResult {
    val result = flashWithIO("${getKsuDaemonPath()} boot-restore -f", onStdout, onStderr)
    return FlashResult(result)
}

fun uninstallPermanently(
    onStdout: (String) -> Unit, onStderr: (String) -> Unit
): FlashResult {
    val result = flashWithIO("${getKsuDaemonPath()} uninstall --package-name ${BuildConfig.APPLICATION_ID}", onStdout, onStderr)
    return FlashResult(result)
}

@Parcelize
sealed class LkmSelection : Parcelable {
    data class LkmUri(val uri: Uri) : LkmSelection()
    data class KmiString(val value: String) : LkmSelection()
    data object KmiNone : LkmSelection()
}

fun installBoot(
    bootUri: Uri?,
    lkm: LkmSelection,
    ota: Boolean,
    allowShell: Boolean,
    enableAdb: Boolean,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit,
): FlashResult {
    val resolver = ksuApp.contentResolver

    val bootFile = bootUri?.let { uri ->
        with(resolver.openInputStream(uri)) {
            val bootFile = File(ksuApp.cacheDir, "boot.img")
            bootFile.outputStream().use { output ->
                this?.copyTo(output)
            }

            bootFile
        }
    }

    var cmd = "boot-patch"

    cmd += if (bootFile == null) {
        // no boot.img, use -f to force install
        " -f"
    } else {
        " -b ${bootFile.absolutePath}"
    }

    if (allowShell) {
        cmd += " --allow-shell"
    }

    if (enableAdb) {
        cmd += " --enable-adbd"
    }

    if (ota) {
        cmd += " -u"
    }

    var lkmFile: File? = null
    when (lkm) {
        is LkmSelection.LkmUri -> {
            lkmFile = with(resolver.openInputStream(lkm.uri)) {
                val file = File(ksuApp.cacheDir, "kernelsu-tmp-lkm.ko")
                file.outputStream().use { output ->
                    this?.copyTo(output)
                }

                file
            }
            cmd += " -m ${lkmFile.absolutePath}"
        }

        is LkmSelection.KmiString -> {
            cmd += " --kmi ${lkm.value}"
        }

        LkmSelection.KmiNone -> {
            // do nothing
        }
    }

    // output dir
    val downloadsDir =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    cmd += " -o $downloadsDir"

    val result = flashWithIO("${getKsuDaemonPath()} $cmd", onStdout, onStderr)
    Log.i("KernelSU", "install boot result: ${result.isSuccess}")

    bootFile?.delete()
    lkmFile?.delete()

    // if boot uri is empty, it is direct install, when success, we should show reboot button
    return FlashResult(result, bootUri == null && result.isSuccess)
}

fun reboot(reason: String = "") {
    if (reason == "soft-reboot") {
        // ksud (userspace)
        com.rifsxd.ksunext.ui.util.execKsud("soft-reboot", true, true)
        return
    }

    if (reason == "recovery") {
        // KEYCODE_POWER = 26, hide incorrect "Factory data reset" message
        ShellUtils.fastCmdResult("/system/bin/input keyevent 26")
    }
    ShellUtils.fastCmdResult("/system/bin/svc power reboot $reason || /system/bin/reboot $reason")
}

fun flashAnyKernelZip(
    uri: Uri,
    approvedSha256: String,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): FlashResult {
    val tmpFile = runCatching { File.createTempFile("anykernel31-", ".zip", ksuApp.cacheDir) }.getOrNull()
    if (tmpFile == null || !AndroidZipPreflight.copyVerified(ksuApp, uri, tmpFile, approvedSha256)) {
        val message = ksuApp.getString(R.string.zip31_changed)
        onStderr(message)
        return FlashResult(1, message, false)
    }

    val destZip = tmpFile.absolutePath
    val destZipName = File(destZip).name
    val destDirFile = File(ksuApp.cacheDir, tmpFile.name + ".work")
    val destDir = destDirFile.absolutePath

    // Validate that the zip contains the required META-INF installer script
    val hasInstaller = runCatching {
        java.util.zip.ZipFile(tmpFile).use { zip ->
            zip.getEntry("META-INF/com/google/android/update-binary") != null
        }
    }.getOrDefault(false)

    if (!hasInstaller) {
        tmpFile.delete()
        val errMsg = "Invalid AnyKernel3 zip: META-INF/com/google/android/update-binary not found!"
        onStderr(errMsg)
        return FlashResult(1, "", false)
    }

    val cmd = """
                mkdir -p '$destDir' && \
                cp '$destZip' '$destDir/$destZipName' && \
                echo '$approvedSha256  $destDir/$destZipName' | $BUSYBOX sha256sum -c - >/dev/null && \
                $BUSYBOX unzip -p -o '$destDir/$destZipName' "META-INF/com/google/android/update-binary" > '$destDir/update-binary' 2>/dev/null && \
                $BUSYBOX chmod 755 '$destDir/update-binary' && \
                $BUSYBOX chown root:root '$destDir/update-binary' && \
                (cd '$destDir' && \
                    if [ -f './update-binary' ]; then \
                        AKHOME='$destDir/tmp' $BUSYBOX ash '$destDir/update-binary' 3 1 '$destDir/$destZipName'; \
                    else \
                        echo 'No installer script found' >&2; exit 1; \
                    fi)
            """.trimIndent().replace(Regex("\\s+\\\\\\s*"), " ")

    try {
        val result = flashWithIO_ak3(cmd, onStdout, onStderr)
        return FlashResult(result, result.isSuccess)
    } finally {
        tmpFile.delete()
        try {
            runCatching {
                createRootShell(true).use { sh ->
                    sh.newJob().add("rm -rf '$destDir' '$destZip'").exec()
                }
            }
        } catch (_: Throwable) {
        }
    }
}

fun rootAvailable() = Shell.isAppGrantedRoot() == true

/**
 * True only when a root shell is reachable AND it is really UID 0.
 *
 * The old version trusted the exit code of the whole `... || sh` chain; because
 * `sh` always succeeds, every device looked rooted and helpers silently ran as
 * uid 2000. libsu already classifies the shell for us (it runs `id` once at
 * startup and only reports ROOT_SHELL on `uid=0`), so `isRoot` is the answer —
 * the explicit `id -u` is kept as a second, cheap confirmation for the case
 * where the shell was built before that check completed.
 */
/**
 * Is there a `su` binary on PATH at all? Purely observational: it runs no
 * command and therefore cannot trigger a prompt. Used only to word the
 * failure correctly.
 */
fun suBinaryPresent(): Boolean = runCatching {
    val paths = System.getenv("PATH").orEmpty().split(':').filter { it.isNotBlank() }
    paths.any { File(it, "su").canExecute() } || File("/system/bin/su").canExecute() ||
        File("/system/xbin/su").canExecute()
}.getOrDefault(false)

/**
 * One-line, device-side explanation of why root was not obtained. Written for
 * the case where the user knows the device IS rooted (KernelSU says so) but the
 * Manager reports NONE: guessing is useless there, so this records what each
 * layer actually answered.
 *
 * Deliberately cheap and safe: a handful of toybox calls through an
 * unprivileged shell, no su prompt, no writes.
 */
suspend fun diagnoseRoot60(): String = withContext(Dispatchers.IO) {
    val facts = ArrayList<String>(6)
    facts += "su:" + if (suBinaryPresent()) "ada" else "tidak"
    facts += "ksu:" + (runCatching { Natives.isManager }.getOrDefault(false))
    facts += "kern:" + runCatching { System.getProperty("os.version").orEmpty() }.getOrDefault("?")
    val probe = runCatching {
        val out = ArrayList<String>()
        Shell.Builder.create().build().use { sh ->
            sh.newJob().add(
                "for a in /proc/self/fd/*; do t=\$(readlink \"\$a\" 2>/dev/null); " +
                "case \"\$t\" in *ksu_driver*) echo driver=ya\$t;; esac; done; " +
                "echo uid=\$(id -u)"
            ).to(out, null).exec()
        }
        out
    }.getOrDefault(ArrayList())
    if (probe.any { it.contains("driver=") }) facts += "driver:ya" else facts += "driver:tidak"
    probe.firstOrNull { it.startsWith("uid=") }?.let { facts += it.trim() }
    facts.joinToString(" · ")
}

fun probeSuRoot(): Boolean {
    if (rootAvailable()) return true
    return runCatching {
        createRootShell(false).use { shell ->
            if (shell.isRoot) return@use true
            val out = ArrayList<String>()
            val job = shell.newJob().add("id -u").to(out, null).exec()
            job.isSuccess && out.firstOrNull()?.trim() == "0"
        }
    }.getOrDefault(false)
}

/**
 * Same probe, mount-master variant. Kept separate because a global mount
 * namespace is required for module helpers but is not offered by every su
 * (Magisk hides it, APatch accepts it); a failure here must fall back to the
 * normal namespace instead of declaring root missing.
 */
fun probeSuRootGlobal(): Boolean {
    return runCatching {
        createRootShell(true).use { shell ->
            if (shell.isRoot) return@use true
            val out = ArrayList<String>()
            val job = shell.newJob().add("id -u").to(out, null).exec()
            job.isSuccess && out.firstOrNull()?.trim() == "0"
        }
    }.getOrDefault(false)
}

fun isInitBoot(): Boolean {
    return !Os.uname().release.contains("android12-")
}

suspend fun getCurrentKmi(): String = withContext(Dispatchers.IO) {
    val cmd = "boot-info current-kmi"
    ShellUtils.fastCmd("${getKsuDaemonPath()} $cmd")
}

suspend fun getSupportedKmis(): List<String> = withContext(Dispatchers.IO) {
    val cmd = "boot-info supported-kmis"
    val out = Shell.cmd("${getKsuDaemonPath()} $cmd").to(ArrayList(), null).exec().out
    out.filter { it.isNotBlank() }.map { it.trim() }
}

suspend fun isAbDevice(): Boolean = withContext(Dispatchers.IO) {
    val cmd = "boot-info is-ab-device"
    ShellUtils.fastCmd("${getKsuDaemonPath()} $cmd").trim().toBoolean()
}

suspend fun getDefaultPartition(): String = withContext(Dispatchers.IO) {
    if (rootAvailable()) {
        val cmd = "boot-info default-partition"
        ShellUtils.fastCmd("${getKsuDaemonPath()} $cmd").trim()
    } else {
        if (!Os.uname().release.contains("android12-")) "init_boot" else "boot"
    }
}

suspend fun getSlotSuffix(ota: Boolean): String = withContext(Dispatchers.IO) {
    val cmd = if (ota) {
        "boot-info slot-suffix --ota"
    } else {
        "boot-info slot-suffix"
    }
    ShellUtils.fastCmd("${getKsuDaemonPath()} $cmd").trim()
}

suspend fun getAvailablePartitions(): List<String> = withContext(Dispatchers.IO) {
    val shell = createRootShell(true)
    val cmd = "boot-info available-partitions"
    val out = shell.newJob().add("${getKsuDaemonPath()} $cmd").to(ArrayList(), null).exec().out
    out.filter { it.isNotBlank() }.map { it.trim() }
}

fun hasMagisk(): Boolean {
    val result = ShellUtils.fastCmdResult("which magisk")
    Log.i(TAG, "has magisk: $result")
    return result
}

fun isSepolicyValid(rules: String?): Boolean {
    if (rules == null) {
        return true
    }
    val result =
        Shell.cmd("${getKsuDaemonPath()} sepolicy check '$rules'").to(ArrayList(), null)
            .exec()
    return result.isSuccess
}

fun getSepolicy(pkg: String): String {
    val result =
        Shell.cmd("${getKsuDaemonPath()} profile get-sepolicy $pkg").to(ArrayList(), null)
            .exec()
    Log.i(TAG, "code: ${result.code}, out: ${result.out}, err: ${result.err}")
    return result.out.joinToString("\n")
}

fun setSepolicy(pkg: String, rules: String): Boolean {
    val result = Shell.cmd("${getKsuDaemonPath()} profile set-sepolicy $pkg '$rules'")
        .to(ArrayList(), null).exec()
    Log.i(TAG, "set sepolicy result: ${result.code}")
    return result.isSuccess
}

fun listAppProfileTemplates(): List<String> {
    return Shell.cmd("${getKsuDaemonPath()} profile list-templates").to(ArrayList(), null)
        .exec().out
}

fun getAppProfileTemplate(id: String): String {
    return Shell.cmd("${getKsuDaemonPath()} profile get-template '${id}'")
        .to(ArrayList(), null).exec().out.joinToString("\n")
}

fun getFileName(context: Context, uri: Uri): String {
    var name = "Unknown Module"
    if (uri.scheme == ContentResolver.SCHEME_CONTENT) {
        val cursor: Cursor? = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                name = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            }
        }
    } else if (uri.scheme == "file") {
        name = uri.lastPathSegment ?: "Unknown Module"
    }
    return name
}

fun currentMountSystem(): String {
    val result = ShellUtils.fastCmd("${getKsuDaemonPath()} module mount").trim()
    return result.substringAfter(":").substringAfter(" ").trim()
}

fun getModuleSize(dir: File): Long {
    val result = ShellUtils.fastCmd("$BUSYBOX du -sb '${dir.absolutePath}' | awk '{print $1}'").trim()
    return result.toLongOrNull() ?: 0L
}

fun isSuCompatDisabled(): Boolean {
    return !Natives.isSuEnabled()
}

fun zygiskRequired(dir: File): Boolean {
    return (SuFile(dir, "zygisk").listFiles()?.size ?: 0) > 0
}

fun isZygiskImpl(dir: File): Boolean {
    return SuFile(dir, "bin/zygiskd").exists() || SuFile(dir, "bin/zygiskd64").exists()
}

fun refreshActivity(context: Context) {
    if (context is Activity) {
        context.recreate()
    }
}

fun restartActivity(context: Context) {
    val packageManager = context.packageManager
    val intent = packageManager.getLaunchIntentForPackage(context.packageName)
    intent?.addFlags(
        Intent.FLAG_ACTIVITY_NEW_TASK or
        Intent.FLAG_ACTIVITY_CLEAR_TASK or
        Intent.FLAG_ACTIVITY_CLEAR_TOP
    )
    context.startActivity(intent)
    if (context is Activity) {
        context.finish()
    }
}

fun getSuSFS(): String {
    return ShellUtils.fastCmd("${getKsuDaemonPath()} susfs support")
}

fun getSuSFSVersion(): String {
    return ShellUtils.fastCmd("${getKsuDaemonPath()} susfs version")
}

fun getSuSFSVariant(): String {
    return ShellUtils.fastCmd("${getKsuDaemonPath()} susfs variant")
}

fun getSuSFSFeatures(): String {
    return ShellUtils.fastCmd("${getKsuDaemonPath()} susfs features")
}

fun getMetaModule(): String {
    return ShellUtils.fastCmd("${getKsuDaemonPath()} module metamodule")
}

fun setAppProfileTemplate(id: String, template: String): Boolean {
    val escapedTemplate = template.replace("'", "'\\''")
    val cmd = """${getKsuDaemonPath()} profile set-template "$id" '$escapedTemplate'"""
    return Shell.cmd(cmd)
        .to(ArrayList(), null).exec().isSuccess
}

fun deleteAppProfileTemplate(id: String): Boolean {
    return Shell.cmd("${getKsuDaemonPath()} profile delete-template '${id}'")
        .to(ArrayList(), null).exec().isSuccess
}

fun forceStopApp(packageName: String) {
    val result = Shell.cmd("am force-stop $packageName").exec()
    Log.i(TAG, "force stop $packageName result: $result")
}

fun launchApp(packageName: String) {
    val result =
        Shell.cmd("cmd package resolve-activity --brief $packageName | tail -n 1 | xargs cmd activity start-activity -n")
            .exec()
    Log.i(TAG, "launch $packageName result: $result")
}

fun restartApp(packageName: String) {
    forceStopApp(packageName)
    launchApp(packageName)
}

fun getRiskStatus(): Boolean? {
    return runCatching {
        val out = ShellUtils
            .fastCmd("${getKsuDaemonPath()} module risk status")
            .trim()

        when {
            out.equals("Enabled", ignoreCase = true) -> true
            out.equals("Disabled", ignoreCase = true) -> false
            else -> null
        }
    }.getOrNull()
}

fun setRisk(enabled: Boolean): Boolean {
    return runCatching {
        val command = if (enabled) "enable" else "disable"

        ShellUtils.fastCmdResult(
            "${getKsuDaemonPath()} module risk $command"
        )
    }.getOrDefault(false)
}
