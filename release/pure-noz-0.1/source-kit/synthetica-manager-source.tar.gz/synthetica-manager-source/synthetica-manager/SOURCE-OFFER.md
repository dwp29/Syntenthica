# Source offer — Synthetica Manager

This file is the written source offer for the `Synthetica Manager` APK, as
required by GPL-3.0 section 6 for a binary distribution.

## What is in this kit

| Component | Where |
| --- | --- |
| Manager (the APK source) | `synthetica-manager/` |
| Build script | `tools/build_manager.py` |
| Verification script | `tools/verify_apk.py` |
| Root daemon (`libksud.so`) | `daemon/libksud.so` — see *Daemon* below |
| Full licence text | `synthetica-manager/LICENSE` |

## Upstream

The Manager is a derivative of KernelSU-Next, which is GPL-3.0:

- <https://github.com/KernelSU-Next/KernelSU-Next>

SuSFS and the kernel-side components live in the same upstream ecosystem. Their
licence texts are under `synthetica-manager/app/src/main/assets/licenses/`.

## Daemon

`libksud.so` is the root daemon the Manager talks to over the KernelSU UAPI. It is
not covered by the Manager's own source: it is a prebuilt binary taken from a
pinned APK and injected at build time.

- expected size: `5518544` bytes
- expected SHA-256: `c305965796afb55ae8dad3a122935c995a818e07c637a9ef4c3e375202e4a427`
- packaged as `lib/arm64-v8a/libksud.so`

`tools/build_manager.py` refuses to build if the daemon in `daemon/` does not match
that size and digest, so a modified daemon cannot be shipped by accident.

## Signing

No signing key is included, and none should be added to a shared archive. The
build script produces an **unsigned** APK on purpose; sign it yourself with any
key you control (see `BUILD.md`). A kernel that pins a specific Manager
certificate will only accept an APK signed with *that* certificate, so a
self-signed build is for your own testing, not a drop-in replacement for an
officially signed release.

## Reproduction

See `BUILD.md` for the exact steps, tool versions and the checks the build runs
before it emits an APK.
