# Building the Synthetica Manager APK

Everything here builds locally. There is no CI file, no remote build service and
no network step in the build itself (Gradle will fetch its own dependencies once).

## 1. Requirements

| Tool | Version used | Notes |
| --- | --- | --- |
| JDK | 21 (Temurin) | Gradle 9.2 requires 17+ |
| Android SDK | platform `android-36` | `ANDROID_SDK_ROOT` must be set |
| Build tools | `36.1.0` | provides `zipalign`, `aapt`, `apksigner` |
| NDK | `29.0.14206865` | for the native `libsynthetica` / su bridge |
| CMake | `3.22.1` | as declared by `app/build.gradle.kts` |
| Python | 3.9+ | runs the build script |
| RAM | 8 GB free | `org.gradle.jvmargs=-Xmx2048m` plus the JVM |

Install the SDK pieces with `sdkmanager`:

```bash
sdkmanager --install 'platform-tools' 'platforms;android-36' \
  'build-tools;36.1.0' 'ndk;29.0.14206865' 'cmake;3.22.1'
```

## 2. Build

```bash
export ANDROID_SDK_ROOT=$HOME/android-sdk
export ANDROID_HOME=$ANDROID_SDK_ROOT

# Optional: switch the package id (default is net.ember.labs, which is the
# released identity; the standalone id installs beside it instead of updating it)
export SYNTHETICA_APP_ID=net.ember.labs.standalone

python3 tools/build_manager.py
```

Output: `out/Manager-6.5.1-UNSIGNED.apk`, zipaligned, **not signed**.

The script runs these gates before it compiles anything, and stops if one fails:

- every file the build needs is present
- no signing material (`*.p12`, `*.jks`, `*.keystore`, `*.pem`, `*.key`, `*.der`) is
  inside the tree
- `app/build.gradle.kts` has no signing config, so the build cannot silently
  produce a half-signed APK
- the packaged `uapi/supercall.h` declares `KERNEL_SU_UAPI_VERSION = 4`
- the theme package still exports the functions the rest of the UI imports
- `daemon/libksud.so` matches the pinned size and SHA-256

Useful flags:

```bash
python3 tools/build_manager.py --verify-only          # just the gates, no compile
python3 tools/build_manager.py --workdir /tmp/mgr --output /tmp/Manager.apk
```

## 3. Sign it yourself

The kit ships no key, on purpose. Create one and sign the unsigned APK:

```bash
BT=$ANDROID_SDK_ROOT/build-tools/36.1.0

keytool -genkeypair -keystore my-release.keystore -storetype PKCS12 \
  -alias manager -keyalg RSA -keysize 4096 -validity 3650 \
  -storepass 'pick-a-password' -keypass 'pick-a-password' \
  -dname "CN=My Manager, O=Me, C=ID"

$BT/zipalign -p -f 4 out/Manager-6.5.1-UNSIGNED.apk out/aligned.apk

$BT/apksigner sign --ks my-release.keystore --ks-key-alias manager \
  --ks-pass 'pass:pick-a-password' --key-pass 'pass:pick-a-password' \
  --min-sdk-version 26 \
  --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true \
  --out out/Manager-6.5.1-SIGNED.apk out/aligned.apk

$BT/apksigner verify --verbose --print-certs out/Manager-6.5.1-SIGNED.apk
```

Keep the keystore **outside** this folder and never commit it. Anyone holding it
can publish updates that Android will accept as yours.

## 4. Verify the result

```bash
python3 tools/verify_apk.py out/Manager-6.5.1-SIGNED.apk
$ANDROID_SDK_ROOT/build-tools/36.1.0/aapt dump badging out/Manager-6.5.1-SIGNED.apk | head -3
```

Expected identity:

```
package: name='net.ember.labs.standalone' versionCode='75100' versionName='6.5.1'
native-code: 'arm64-v8a'
```

## 5. About kernel compatibility

A Synthetica/pure-noz kernel pins the **certificate** of the Manager APK it will
accept. An APK signed with your own key is not recognised by such a kernel; the
Manager still works as a universal manager on other KernelSU-compatible kernels
through `su`.

If you are building your own kernel, pin your own certificate instead — the
kernel side takes a SHA-256 of the signing certificate (DER) plus its length.

## 6. Troubleshooting

| Symptom | Cause |
| --- | --- |
| `SDK location not found` | `ANDROID_SDK_ROOT` unset, or `local.properties` missing |
| `Unsupported class file major version` | JDK older than 17 in `JAVA_HOME` |
| `NDK not configured` | NDK 29.0.14206865 not installed |
| `No space left on device` | Gradle caches plus NDK need ~10 GB |
| `daemon/libksud.so does not match` | the daemon file was replaced or truncated |
