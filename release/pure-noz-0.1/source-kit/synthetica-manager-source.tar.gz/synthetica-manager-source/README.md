# Synthetica Manager — source kit

Source for the **Synthetica Manager** Android app, plus the scripts needed to
build, sign and check it.

```
.
├── BUILD.md                  step-by-step build, signing and troubleshooting
├── synthetica-manager/       the app source (Gradle project)
│   ├── app/src/main/java/    Kotlin sources
│   ├── app/src/main/cpp/     native bridge + KernelSU UAPI headers
│   ├── app/src/main/res/     resources, themes, translations
│   ├── LICENSE               GPL-3.0, full text
│   ├── NOTICE                what this is, licence, source offer summary
│   └── SOURCE-OFFER.md       GPL-3.0 §6 written offer
├── daemon/libksud.so         prebuilt root daemon (pinned size + SHA-256)
└── tools/
    ├── build_manager.py      verify the tree, build the unsigned APK
    └── verify_apk.py         structural checks on the built APK
```

## Quick start

```bash
export ANDROID_SDK_ROOT=$HOME/android-sdk
python3 tools/build_manager.py          # -> out/Manager-6.5.1-UNSIGNED.apk
```

Then sign it with your own key — see `BUILD.md` section 3. The kit contains no
signing key and will refuse to ship one.

## Identity of this source

| | |
| --- | --- |
| Package (default) | `net.ember.labs` |
| Package (standalone) | `net.ember.labs.standalone` |
| Version | 6.5.1 (versionCode 75100) |
| KernelSU UAPI | 4 |
| ABI | arm64-v8a |
| Licence | GPL-3.0-only |

## Where this comes from

The app is a derivative of **KernelSU-Next** (GPL-3.0). Upstream:
<https://github.com/KernelSU-Next/KernelSU-Next>

`daemon/libksud.so` is not source: it is a prebuilt binary injected at build time
and is verified against a pinned SHA-256 so a swapped daemon fails the build.

## What is intentionally not here

- signing keys or keystores, and their passwords
- personal contact details in the About screen or the resource strings
- CI configuration, build logs, release notes or any other build-history file

If you redistribute an APK built from this kit, keep `synthetica-manager/` and
`SOURCE-OFFER.md` with it — GPL-3.0 asks you to.
