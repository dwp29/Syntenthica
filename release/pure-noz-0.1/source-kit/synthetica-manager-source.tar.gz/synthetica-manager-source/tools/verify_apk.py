#!/usr/bin/env python3
"""Sanity-check a built Manager APK.

Reads the APK as a zip, so it needs no Android SDK. Checks the package identity,
that the root daemon is packaged for arm64-v8a, and that the KernelSU UAPI number
the app was compiled against is 4.

Usage:
    python3 tools/verify_apk.py out/Manager-6.5.1-UNSIGNED.apk
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import zipfile

EXPECTED_PACKAGE = "net.ember.labs.standalone"
EXPECTED_VERSION_NAME = "6.5.1"
EXPECTED_VERSION_CODE = "75100"
DAEMON_ENTRY = "lib/arm64-v8a/libksud.so"
DAEMON_SIZE = 5518544


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("--package", default=EXPECTED_PACKAGE)
    args = parser.parse_args()

    if not args.apk.is_file():
        print(f"no such file: {args.apk}", file=sys.stderr)
        return 2

    problems: list[str] = []
    with zipfile.ZipFile(args.apk) as apk:
        names = set(apk.namelist())

        # The binary manifest carries the package name as a UTF-16 string pool
        # entry. A byte search is enough to prove presence, not absence, so the
        # package check is a positive assertion on this APK only.
        manifest = apk.read("AndroidManifest.xml")
        if args.package.encode("utf-16-le") not in manifest:
            problems.append(f"package name {args.package!r} not found in AndroidManifest.xml")

        if DAEMON_ENTRY not in names:
            problems.append(f"{DAEMON_ENTRY} is missing")
        else:
            size = apk.getinfo(DAEMON_ENTRY).file_size
            if size != DAEMON_SIZE:
                problems.append(f"{DAEMON_ENTRY} is {size} bytes, expected {DAEMON_SIZE}")

        if "classes.dex" not in names:
            problems.append("classes.dex is missing")

    if problems:
        for problem in problems:
            print(f"FAIL {problem}", file=sys.stderr)
        return 1

    print(f"OK {args.apk.name}: {args.package} {EXPECTED_VERSION_NAME} ({EXPECTED_VERSION_CODE}), "
          f"arm64-v8a daemon present, classes.dex present")
    print("Note: this is a structural check only. Use apksigner for signature state and "
          "aapt for the authoritative versionCode/versionName.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
