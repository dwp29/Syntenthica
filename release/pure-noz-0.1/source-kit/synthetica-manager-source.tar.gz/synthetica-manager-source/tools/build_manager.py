#!/usr/bin/env python3
"""Build the unsigned Synthetica Manager APK from the source tree next to this script.

Nothing is downloaded: `synthetica-manager/` is the complete Manager source. The
build injects the prebuilt root daemon from `daemon/libksud.so` (checked against a
pinned size and digest), runs Gradle, and zipaligns the result.

Signing is deliberately not part of this script. Use apksigner yourself, with a
key you control.
"""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import re

KIT = Path(__file__).resolve().parents[1]
TREE = KIT / "synthetica-manager"
DAEMON = KIT / "daemon" / "libksud.so"
DEFAULT_OUT = KIT / "out" / "Manager-6.5.1-UNSIGNED.apk"

APP_ID = "net.ember.labs"
STANDALONE_APP_ID = "net.ember.labs.standalone"
APP_ID_OVERRIDE = os.environ.get("SYNTHETICA_APP_ID", "").strip()
VERSION_NAME = "6.5.1"
VERSION_CODE = 75100
UAPI = 4

DAEMON_SHA256 = "c305965796afb55ae8dad3a122935c995a818e07c637a9ef4c3e375202e4a427"
DAEMON_SIZE = 5518544

REQUIRED_FILES = (
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradle.properties",
    "gradlew",
    "gradle/wrapper/gradle-wrapper.jar",
    "gradle/wrapper/gradle-wrapper.properties",
    "gradle/libs.versions.toml",
    "app/build.gradle.kts",
    "app/proguard-rules.pro",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/cpp/CMakeLists.txt",
    "app/src/main/cpp/jni.cc",
    "app/src/main/cpp/ksu.cc",
    "app/src/main/cpp/ksu.h",
    "app/src/main/cpp/uapi/supercall.h",
    "app/src/main/cpp/uapi/ksu.h",
    "app/src/main/assets/synthetica-control40.sh",
    "app/src/main/assets/synthetica-boost40.sh",
    "app/src/main/assets/synthetica-universal60.sh",
    "app/src/main/java/com/rifsxd/ksunext/Natives.kt",
    "app/src/main/java/com/rifsxd/ksunext/ui/theme/VisualStyles.kt",
    "app/src/main/java/com/rifsxd/ksunext/ui/theme/CustomWallpaper.kt",
    "app/src/main/java/com/rifsxd/ksunext/ui/theme/Theme.kt",
    "app/src/main/java/com/rifsxd/ksunext/ui/theme/AppearanceControls.kt",
    "app/src/main/java/com/rifsxd/ksunext/ui/util/PixelRootActions40.kt",
    "app/src/main/res/values/strings_manager50.xml",
    "app/src/main/res/values-in-rID/strings_manager50.xml",
    "scripts/update_binary.sh",
    "scripts/updater_script.sh",
    "LICENSE",
)

THEME_API = (
    "fun shapesForStyle",
    "fun managerDockSpec",
    "data class ManagerDockSpec",
    "fun accentTierForStyle",
    "fun typographyForStyle",
    "fun emblemResForStyle",
    "fun splashTagForStyle",
    "fun signatureColorForStyle",
    "fun motionForStyle",
    "fun shapePhaseForMotion",
    "fun exportManagerConfigJson",
    "fun importManagerConfigJson",
)

FORBIDDEN_SUFFIXES = (".p12", ".jks", ".keystore", ".pem", ".key", ".der")


def run(cmd: list[str], cwd: Path | None = None, env: dict[str, str] | None = None) -> None:
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=cwd, env=env, check=True)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fail(message: str) -> None:
    raise RuntimeError(message)


def verify_tree() -> None:
    """Static gates so a broken or secret-bearing tree is never compiled."""
    if not TREE.is_dir():
        fail(f"Manager source tree missing: {TREE}")
    for relative in REQUIRED_FILES:
        if not (TREE / relative).is_file():
            fail(f"Source tree is missing {relative}")
    for path in TREE.rglob("*"):
        if path.is_symlink():
            fail(f"Symlink in the source tree is not supported: {path.relative_to(TREE)}")
        if path.is_file() and path.suffix.lower() in FORBIDDEN_SUFFIXES:
            fail(f"Secret material must never be shipped: {path.relative_to(TREE)}")

    root_gradle = (TREE / "build.gradle.kts").read_text(encoding="utf-8")
    for anchor in (
        f"val managerVersionCode by extra({VERSION_CODE})",
        f'val managerVersionName by extra("{VERSION_NAME}")',
    ):
        if anchor not in root_gradle:
            fail(f"Root build.gradle.kts lacks {anchor!r}")

    app_gradle = (TREE / "app/build.gradle.kts").read_text(encoding="utf-8")
    if APP_ID_OVERRIDE:
        if APP_ID_OVERRIDE not in (APP_ID, STANDALONE_APP_ID):
            fail(f"Unknown app id {APP_ID_OVERRIDE!r}")
    elif f'applicationId = "{APP_ID}"' not in app_gradle:
        fail(f"applicationId must be {APP_ID}")
    for forbidden in ("apksign {", "signingConfig =", "storeFileProperty"):
        if forbidden in app_gradle:
            fail("The build must stay unsigned; sign the APK yourself afterwards")
    if not re.search(r'outputFileName = "Synthetica-6\.\d+\.\d+-Standalone-\$name\.apk"', app_gradle):
        fail("Unexpected APK output name in app/build.gradle.kts")

    supercall = (TREE / "app/src/main/cpp/uapi/supercall.h").read_text(encoding="utf-8")
    if "static const __u32 KERNEL_SU_UAPI_VERSION = 4;" not in supercall:
        fail("The packaged UAPI header is not version 4")

    manifest = (TREE / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
    if "android.permission.INTERNET" not in manifest:
        fail("Unexpected manifest: the Manager needs INTERNET for module downloads")

    verify_theme_api()
    verify_daemon()
    verify_no_personal_data()

    print(f"[verify] {APP_ID_OVERRIDE or APP_ID} {VERSION_NAME} ({VERSION_CODE}); UAPI {UAPI}; source tree OK", flush=True)


def verify_theme_api() -> None:
    theme_dir = TREE / "app/src/main/java/com/rifsxd/ksunext/ui/theme"
    haystack = "\n".join(p.read_text(encoding="utf-8") for p in theme_dir.glob("*.kt"))
    for declaration in THEME_API:
        if not re.search(rf"\b{declaration}\b", haystack):
            fail(f"Theme API declaration disappeared: {declaration}")
    for retired in ("RETRO_ARCADE", "ANIME_WIBU", "GOTHIC_CRIMSON"):
        if re.search(rf"\b{retired}\b", haystack):
            fail(f"Retired theme {retired} is back in the theme package")


# A redistributable source kit must not carry contact details or traces of the
# machine that produced it. The patterns are kept as digests rather than plain
# strings so this file cannot itself leak the very words it screens for.
#
# Each entry is the first 8 bytes of sha256(lowercased pattern).
FORBIDDEN_DIGESTS = (
    "a1f8e8b9",  # maintainer handle
    "671e3ffb",  # maintainer telegram url
    "4ebe44bc",  # assistant web app domain
    "c857d09d",  # assistant chat product
    "60965168",  # assistant chat product
    "7d3194f7",  # ai vendor
    "c70eca6b",  # ai vendor
    "b98d692c",  # ci sandbox home directory
    "2541898c",  # ci sandbox scratch directory
    "489cd3d0",  # ci sandbox domain
)

SKIP_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".ttf", ".otf", ".woff", ".woff2", ".so")


def _digest_heads(path: Path) -> set[str]:
    """Digest heads for every word and every slash-boundary prefix of a path.

    A plain word is hashed whole; a path also hashes its prefixes, so a deep
    path still matches a shallower pattern that is a prefix of it.
    """
    heads: set[str] = set()

    def add(token: str) -> None:
        if token:
            heads.add(hashlib.sha256(token.lower().encode()).hexdigest()[:8])

    for raw in path.read_text(encoding="utf-8", errors="ignore").split():
        token = raw.strip("\"'`,;:()[]{}<>|")
        add(token)
        if "/" in token:
            parts = token.split("/")
            for i in range(2, len(parts) + 1):
                add("/".join(parts[:i]))
    return heads


def verify_no_personal_data() -> None:
    """Refuse to build a tree that carries personal or tooling traces."""
    hits: list[str] = []
    wanted = set(FORBIDDEN_DIGESTS)
    for path in TREE.rglob("*"):
        if not path.is_file() or path.suffix.lower() in SKIP_SUFFIXES:
            continue
        try:
            found = _digest_heads(path) & wanted
        except OSError:
            continue
        if found:
            hits.append(f"{path.relative_to(TREE)} (pattern digest {sorted(found)[0]})")
    if hits:
        fail("Personal or tooling traces found in the tree:\n  " + "\n  ".join(hits[:10]))
    print(f"[verify] no personal data or tooling traces ({len(wanted)} patterns)", flush=True)


def verify_daemon() -> None:
    """The daemon is a binary, so pin it by size and digest, not by trust."""
    if not DAEMON.is_file():
        fail(f"Missing root daemon: {DAEMON}")
    data = DAEMON.read_bytes()
    if len(data) != DAEMON_SIZE or hashlib.sha256(data).hexdigest() != DAEMON_SHA256:
        fail(f"{DAEMON} does not match the pinned daemon size and SHA-256")
    print(f"[verify] daemon OK: {DAEMON_SIZE} bytes, {DAEMON_SHA256[:16]}...", flush=True)


def inject_daemon(app_main: Path) -> str:
    if not DAEMON.is_file():
        fail(f"Missing root daemon: {DAEMON}")
    data = DAEMON.read_bytes()
    if len(data) != DAEMON_SIZE or hashlib.sha256(data).hexdigest() != DAEMON_SHA256:
        fail(f"{DAEMON} does not match the pinned daemon size and SHA-256")
    target = app_main / "jniLibs" / "arm64-v8a" / "libksud.so"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    os.chmod(target, 0o755)
    print(f"[daemon] Injected {DAEMON_SIZE} bytes -> jniLibs/arm64-v8a/libksud.so", flush=True)
    return DAEMON_SHA256


def prepare_copy(work: Path) -> Path:
    if work.exists():
        shutil.rmtree(work)
    shutil.copytree(
        TREE,
        work,
        ignore=shutil.ignore_patterns(
            "build", ".gradle", ".kotlin", ".idea", ".cxx", "local.properties", "*.iml", "jniLibs",
        ),
    )
    os.chmod(work / "gradlew", 0o755)
    app_id = APP_ID_OVERRIDE or APP_ID
    if app_id != APP_ID:
        gradle = work / "app" / "build.gradle.kts"
        text = gradle.read_text(encoding="utf-8")
        gradle.write_text(text.replace(f'applicationId = "{APP_ID}"', f'applicationId = "{app_id}"'),
                          encoding="utf-8")
        print(f"[prepare] applicationId -> {app_id}", flush=True)
    return work


def build_gradle(work: Path) -> Path:
    env = os.environ.copy()
    env.setdefault("GRADLE_OPTS", "-Xmx4g -Dfile.encoding=UTF-8")
    run([str(work / "gradlew"), ":app:assembleRelease", "--no-daemon", "--stacktrace"], cwd=work, env=env)
    apks = sorted((work / "app" / "build" / "outputs" / "apk" / "release").glob("*.apk"))
    if len(apks) != 1:
        fail(f"Expected exactly one release APK, found {[p.name for p in apks]}")
    return apks[0]


def find_tool(name: str) -> str:
    found = shutil.which(name)
    if found:
        return found
    sdk = os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME") or ""
    if sdk:
        candidates = sorted(Path(sdk, "build-tools").glob(f"*/{name}"), reverse=True)
        if candidates:
            return str(candidates[0])
    fail(f"{name} not found in PATH or ANDROID_SDK_ROOT/build-tools")


def zipalign_apk(built_apk: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    run([find_tool("zipalign"), "-p", "-f", "4", str(built_apk), str(output)])
    print(f"[done] Aligned unsigned APK -> {output} ({output.stat().st_size} bytes)", flush=True)
    print(f"[done] SHA-256 {sha256(output)}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true", help="run the static gates; build nothing")
    parser.add_argument("--workdir", type=Path, help="temporary copy of the source tree")
    parser.add_argument("--output", type=Path, help="aligned unsigned APK destination")
    args = parser.parse_args()

    verify_tree()
    if args.verify_only:
        print("[done] Static gates only; no APK built")
        return 0

    output = args.output or DEFAULT_OUT
    work = args.workdir or Path(tempfile.mkdtemp(prefix="synthetica-manager-")) / "manager"
    prepared = prepare_copy(work)
    inject_daemon(prepared / "app" / "src" / "main")
    built = build_gradle(prepared)
    zipalign_apk(built, output)
    return 0


if __name__ == "__main__":
    sys.exit(main())
